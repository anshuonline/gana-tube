// ── Global Process Crash Guards ──
// Prevents unhandled errors from terminating Node and causing LiteSpeed 403 Forbidden
process.on('uncaughtException', (err) => {
  console.error('[CRITICAL] Uncaught Exception:', err);
});
process.on('unhandledRejection', (reason, promise) => {
  console.error('[CRITICAL] Unhandled Rejection at:', promise, 'reason:', reason);
});

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const compression = require('compression');
const YTMusic = require('ytmusic-api');
const http = require('http');
const { Server } = require('socket.io');
const fs = require('fs');
const path = require('path');
const { nanoid } = require('nanoid');
const app = express();
app.use(compression()); // Enable gzip compression for all responses
const server = http.createServer(app);
server.on('error', (err) => {
  console.error('[CRITICAL] HTTP Server Error:', err);
});
const io = new Server(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});
const PORT = process.env.PORT || 3000;

const { setupRoomHandlers, handleRoomDisconnect, initBotRooms, getRoomAnalytics, createDiscordRoom, deleteDiscordRoom } = require('./room.js');

app.use(express.json());

// ── Discord Bot Room Creation Endpoint ──
app.post('/api/rooms/create-discord-room', (req, res) => {
  const { name, initialTrack } = req.body || {};
  try {
    const room = createDiscordRoom({ name, initialTrack });
    res.json({
      success: true,
      roomId: room.roomId,
      name: room.name,
      roomUrl: `https://ganatube.in/rooms/${room.roomId}`
    });
  } catch (err) {
    console.error('Failed to create discord room:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/rooms/delete-discord-room', (req, res) => {
  const { roomId } = req.body || {};
  const deleted = deleteDiscordRoom(roomId);
  res.json({ success: deleted });
});


io.on('connection', (socket) => {
  console.log('User connected:', socket.id);

  socket.on('disconnect', () => {
    console.log('User disconnected:', socket.id);

    // --- Listening Rooms cleanup ---
    handleRoomDisconnect(io, socket.id);
  });

  // --- Listening Rooms Events ---
  setupRoomHandlers(io, socket);
});

app.use(cors());
app.use(express.json());

// ── Global IP Rate Limiter (Protects server from rogue client loops & bots) ──
const ipRequestWindow = new Map();
const RATE_LIMIT_WINDOW_MS = 60 * 1000; // 1 minute window
const MAX_REQUESTS_PER_MINUTE = 150;     // Max 150 requests per minute per IP (~2.5 req/sec sustained)

// Auto-cleanup stale IP records every 60 seconds
setInterval(() => {
  const now = Date.now();
  for (const [ip, data] of ipRequestWindow.entries()) {
    if (now - data.windowStart > RATE_LIMIT_WINDOW_MS) {
      ipRequestWindow.delete(ip);
    }
  }
}, RATE_LIMIT_WINDOW_MS);

app.use((req, res, next) => {
  // Extract real client IP behind Cloudflare / LiteSpeed proxies
  const clientIp = req.headers['cf-connecting-ip'] || 
                   req.headers['x-real-ip'] || 
                   (req.headers['x-forwarded-for'] ? req.headers['x-forwarded-for'].split(',')[0].trim() : '') || 
                   req.socket.remoteAddress || 
                   'unknown';

  const now = Date.now();
  let record = ipRequestWindow.get(clientIp);

  if (!record || (now - record.windowStart) > RATE_LIMIT_WINDOW_MS) {
    record = { windowStart: now, count: 1 };
    ipRequestWindow.set(clientIp, record);
    return next();
  }

  record.count++;

  if (record.count > MAX_REQUESTS_PER_MINUTE) {
    res.setHeader('Retry-After', '60');
    return res.status(429).json({ 
      error: 'Too Many Requests', 
      message: 'Rate limit exceeded. Please wait a moment.' 
    });
  }

  next();
});

let ytmusicInstance = null;

// Artist data cache (24h TTL) — artist images/data rarely change
const artistCache = new Map();
const ARTIST_CACHE_TTL = 24 * 60 * 60 * 1000;

// Initialize YTMusic instance once
async function getYTMusic() {
  if (!ytmusicInstance) {
    console.log('Initializing YTMusic...');
    const ytmusic = new YTMusic();
    await ytmusic.initialize();
    ytmusicInstance = ytmusic;
    console.log('YTMusic initialized successfully!');
  }
  return ytmusicInstance;
}

// ─── Bot Rooms: trending song pool for auto-play (cron-driven) ──────────────
function parseDurationToSeconds(d) {
  if (typeof d === 'number' && d > 0) return d;
  if (typeof d === 'string') {
    const parts = d.split(':').map(p => parseInt(p, 10));
    if (parts.length === 2 && parts.every(p => !isNaN(p))) return parts[0] * 60 + parts[1];
    if (parts.length === 3 && parts.every(p => !isNaN(p))) return parts[0] * 3600 + parts[1] * 60 + parts[2];
  }
  return 0;
}

// Universal helper to upgrade any YouTube Music / Video / Playlist / Album thumbnail to HD
function toHDUrl(url) {
  if (!url) return '';
  if (url.includes('googleusercontent.com') || url.includes('ggpht.com')) {
    let u = url;
    if (/=w\d+-h\d+/i.test(u)) {
      u = u.replace(/=w\d+-h\d+[^=]*/i, '=w544-h544-l90-rj');
    } else if (/-w\d+-h\d+/i.test(u)) {
      u = u.replace(/-w\d+-h\d+[^=]*/i, '-w544-h544-l90-rj');
    } else if (/=s\d+/i.test(u)) {
      u = u.replace(/=s\d+(-[a-zA-Z0-9_-]*)?/i, '=s544-c-k-c0x00ffffff-no-rj');
    } else if (/-s\d+/i.test(u)) {
      u = u.replace(/-s\d+(-[a-zA-Z0-9_-]*)?/i, '-s544-c-k-c0x00ffffff-no-rj');
    } else if (/\/s\d+\//i.test(u)) {
      u = u.replace(/\/s\d+\//i, '/s544/');
    } else if (!u.includes('=')) {
      u = u + '=w544-h544-l90-rj';
    }
    return u;
  }
  if (url.includes('ytimg.com') || url.includes('youtube.com')) {
    let cleanUrl = url.split('?')[0];
    if (cleanUrl.includes('/default.jpg') || cleanUrl.includes('/mqdefault.jpg') || cleanUrl.includes('/sddefault.jpg')) {
      cleanUrl = cleanUrl.replace(/\/(default|mqdefault|sddefault)\.jpg$/i, '/hqdefault.jpg');
    }
    return cleanUrl;
  }
  return url;
}

async function getBotSongs() {
  const yt = await getYTMusic();
  const queries = ['Trending Hindi Songs', 'Trending English Songs'];
  const results = await Promise.all(queries.map(q => yt.searchSongs(q).catch(() => [])));

  const toHDUrl = (url) => {
    if (!url) return '';
    if (url.includes('img.youtube.com')) {
      return url.replace('/default.jpg', '/hqdefault.jpg');
    }
    return url
      .replace(/=w\d+-h\d+/, '=w600-h600')
      .replace(/-w\d+-h\d+/, '-w600-h600')
      .replace(/\/s\d+-/, '/s600-');
  };

  const mapped = [];
  for (const list of results) {
    for (const item of (list || [])) {
      const artistName = item.artist && typeof item.artist === 'object'
        ? item.artist.name
        : (typeof item.artist === 'string' ? item.artist : 'Unknown Artist');
      const videoId = item.videoId;
      if (!videoId) continue;
      const thumbs = item.thumbnails || [];
      mapped.push({
        videoId,
        title: item.name || item.title,
        channelTitle: artistName,
        thumbnail: toHDUrl(thumbs[0]?.url || ''),
        thumbnailHigh: toHDUrl(thumbs[thumbs.length - 1]?.url || ''),
        duration: parseDurationToSeconds(item.duration),
        publishedAt: new Date().toISOString()
      });
    }
  }
  return mapped;
}

  async function fetchRoombotsConfig() {
    try {
      const response = await fetch('https://manageads.ganatube.in/managegt-api.php?action=get_roombots');
      const data = await response.json();
      return Array.isArray(data) ? data : [];
    } catch (e) {
      console.warn('Failed to fetch roombots config from API, using fallback', e.message);
      return [];
    }
  }

  async function getPlaylistSongs(playlistId) {
    if (!playlistId) return [];
    try {
      const yt = await getYTMusic();
      let pid = playlistId;
      if (pid.includes('list=')) {
        try { pid = new URL(pid).searchParams.get('list') || pid; } catch(e){}
      } else if (pid.includes('/playlist/')) {
        pid = pid.split('/playlist/')[1].split('?')[0];
      }
      if (pid.startsWith('VL')) {
        pid = pid.substring(2);
      }
      
      let videos = [];
      if (pid.startsWith('RD')) {
        const data = await yt.constructRequest('next', { playlistId: pid, isAudioOnly: true });
        const contents = data.contents?.singleColumnMusicWatchNextResultsRenderer?.tabbedRenderer?.watchNextTabbedResultsRenderer?.tabs[0]?.tabRenderer?.content?.musicQueueRenderer?.content?.playlistPanelRenderer?.contents || [];
        videos = contents.map(item => item.playlistPanelVideoRenderer).filter(Boolean).map(item => ({
          videoId: item.videoId,
          name: item.title?.runs?.[0]?.text || 'Unknown',
          artist: item.shortBylineText?.runs?.map(r => r.text).join('') || 'Unknown Artist',
          thumbnails: item.thumbnail?.thumbnails || [],
          duration: item.lengthText?.runs?.[0]?.text || '0:00'
        }));
      } else {
        videos = await yt.getPlaylistVideos(pid);
      }
      
      return (videos || []).map(song => ({
        videoId: song.videoId,
        title: song.name || song.title,
        channelTitle: (song.artist && song.artist.name) || (typeof song.artist === 'string' ? song.artist : 'Unknown Artist'),
        thumbnail: toHDUrl(song.thumbnails && song.thumbnails.length > 0 ? song.thumbnails[0].url : ''),
        thumbnailHigh: toHDUrl(song.thumbnails && song.thumbnails.length > 0 ? song.thumbnails[song.thumbnails.length - 1].url : ''),
        duration: parseDurationToSeconds(song.duration),
        publishedAt: new Date().toISOString()
      }));
    } catch (e) {
      console.warn(`Failed to fetch playlist ${playlistId} for bots:`, e.message);
      return [];
    }
  }

  fetchRoombotsConfig().then(roombotsConfig => {
    initBotRooms(io, getBotSongs, roombotsConfig, getPlaylistSongs);
  });

// ─── Smart Query Enhancement ────────────────────────────────────────────────
// ytmusic-api's search is biased toward the server's regional language (Hindi).
// We detect the user's intent and reinforce the query so results stay on-topic.

const ENGLISH_TRIGGERS = [
  'english', 'pop', 'rock', 'rap', 'hip hop', 'hiphop', 'r&b', 'rnb',
  'jazz', 'country', 'blues', 'metal', 'indie', 'edm', 'dance',
  'taylor swift', 'ed sheeran', 'dua lipa', 'weeknd', 'drake', 'eminem',
  'billie eilish', 'ariana grande', 'bruno mars', 'adele', 'coldplay',
  'imagine dragons', 'post malone', 'the beatles', 'michael jackson'
];

const HINDI_TRIGGERS = [
  'hindi', 'bollywood', 'arijit', 'atif', 'kumar sanu', 'lata mangeshkar',
  'kishore kumar', 'sonu nigam', 'shreya ghoshal', 'neha kakkar', 'badshah',
  'udit narayan', 'asha bhosle', 'rafi', 'mukesh', 'armaan malik'
];

function enhanceQuery(rawQuery) {
  const q = rawQuery.toLowerCase().trim();

  const isEnglish = ENGLISH_TRIGGERS.some(t => q.includes(t));
  const isHindi   = HINDI_TRIGGERS.some(t => q.includes(t));

  // If the user's query clearly points to English content, append
  // a strong English-language signal that YTMusic understands.
  if (isEnglish && !isHindi) {
    // Don't double-add the word if already present
    if (!q.includes('english')) {
      return `${rawQuery} english`;
    }
    return rawQuery;
  }

  // Hindi / Bollywood — keep as-is; the API already defaults well for these
  return rawQuery;
}
// ────────────────────────────────────────────────────────────────────────────

const trendingCache = {};

app.get('/api/trending', async (req, res) => {
  const lang = req.query.lang || 'Hindi';
  const limit = parseInt(req.query.limit) || 12;
  const cacheKey = lang.toLowerCase();

  // 1 hour cache (3600000 ms)
  if (trendingCache[cacheKey] && (Date.now() - trendingCache[cacheKey].timestamp < 3600000)) {
    let results = [...trendingCache[cacheKey].results];
    // Shuffle the cached results so it looks different on refresh
    results = results.sort(() => 0.5 - Math.random());
    return res.json(results.slice(0, limit));
  }

  try {
    const yt = await getYTMusic();
    const query = `Trending ${lang} Songs`;
    let results = await yt.searchSongs(query);

    const mappedResults = results.map(item => {
      const artistName = item.artist && typeof item.artist === 'object' 
        ? item.artist.name 
        : (typeof item.artist === 'string' ? item.artist : 'Unknown Artist');
        
      const videoId = item.videoId || item.albumId || item.playlistId;

      let thumbnailLow = item.thumbnails && item.thumbnails.length > 0
        ? item.thumbnails[0].url
        : `https://img.youtube.com/vi/${videoId}/default.jpg`;

      let thumbnailHigh = item.thumbnails && item.thumbnails.length > 0
        ? item.thumbnails[item.thumbnails.length - 1].url
        : `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;

      return {
        videoId: videoId,
        title: item.name || item.title,
        channelTitle: artistName,
        thumbnail: toHDUrl(thumbnailLow),
        thumbnailHigh: toHDUrl(thumbnailHigh),
        duration: item.duration,
        publishedAt: new Date().toISOString(),
        type: 'song'
      };
    });

    trendingCache[cacheKey] = {
      timestamp: Date.now(),
      results: mappedResults
    };

    let shuffled = [...mappedResults].sort(() => 0.5 - Math.random());
    res.json(shuffled.slice(0, limit));
  } catch (error) {
    console.error('Error fetching trending:', error);
    res.status(500).json({ error: 'Failed to fetch trending songs' });
  }
});

// Search endpoint
app.get('/api/songs', async (req, res) => {
  const rawQuery = req.query.q;
  if (!rawQuery) {
    return res.status(400).json({ error: 'Search query parameter "q" is required' });
  }

  const query = enhanceQuery(rawQuery);   // ← apply smart enhancement

  try {
    const yt = await getYTMusic();
    const limit = parseInt(req.query.limit) || 20;
    const type = req.query.type || 'song';
    console.log(`Searching ${type}s: "${rawQuery}" → enhanced: "${query}" (limit: ${limit})`);
    
    let results = [];
    if (type === 'album') {
      results = await yt.searchAlbums(query);
    } else if (type === 'playlist') {
      results = await yt.searchPlaylists(query);
    } else {
      results = await yt.searchSongs(query);
    }
    
    // Always enforce the limit, whether it is 1 or 50.
    if (results && results.length > limit) {
      results = results.slice(0, limit);
    }

    // Map to standard YouTubeSearchResult format expected by Angular frontend
    const mappedResults = results.map(item => {
      const artistName = item.artist && typeof item.artist === 'object' 
        ? item.artist.name 
        : (typeof item.artist === 'string' ? item.artist : 'Unknown Artist');
        
      const videoId = item.videoId || item.albumId || item.playlistId;

      let thumbnailLow = item.thumbnails && item.thumbnails.length > 0
        ? item.thumbnails[0].url
        : `https://img.youtube.com/vi/${videoId}/default.jpg`;

      let thumbnailHigh = item.thumbnails && item.thumbnails.length > 0
        ? item.thumbnails[item.thumbnails.length - 1].url
        : `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;

      return {
        videoId: videoId,
        title: item.name || item.title,
        channelTitle: artistName,
        thumbnail: toHDUrl(thumbnailLow),
        thumbnailHigh: toHDUrl(thumbnailHigh),
        duration: item.duration,
        publishedAt: new Date().toISOString(),
        type: type // return the requested type to help frontend routing
      };
    });

    res.json(mappedResults);
  } catch (error) {
    console.error('Error during search:', error);
    res.status(500).json({ error: 'An error occurred during search' });
  }
});

// Album details endpoint
app.get('/api/album', async (req, res) => {
  const id = req.query.id;
  if (!id) return res.status(400).json({ error: 'id required' });
  try {
    const yt = await getYTMusic();
    const album = await yt.getAlbum(id);
    
    // getAlbum returns metadata but 0 songs, so use playlistId with getPlaylistVideos
    let songs = [];
    const albumPlaylistId = album.playlistId;
    if (albumPlaylistId) {
      try {
        const videos = await yt.getPlaylistVideos(albumPlaylistId);
        songs = (videos || []).map(song => ({
          videoId: song.videoId,
          title: song.name || song.title,
          channelTitle: (song.artist && song.artist.name) || (album.artist && album.artist.name) || 'Unknown Artist',
          thumbnail: toHDUrl(song.videoId ? `https://i.ytimg.com/vi/${song.videoId}/mqdefault.jpg` : 
                     (song.thumbnails && song.thumbnails.length > 0 ? song.thumbnails[0].url : '')),
          thumbnailHigh: toHDUrl(song.videoId ? `https://i.ytimg.com/vi/${song.videoId}/hqdefault.jpg` : 
                        (song.thumbnails && song.thumbnails.length > 0 ? song.thumbnails[song.thumbnails.length - 1].url : '')),
          duration: song.duration,
          publishedAt: album.year ? `${album.year}-01-01T00:00:00Z` : new Date().toISOString()
        }));
      } catch (e) {
        console.warn('getPlaylistVideos failed for album, falling back:', e.message);
      }
    }
    
    // If getPlaylistVideos failed, try mapping from album.songs (may still be 0)
    if (songs.length === 0 && album.songs && album.songs.length > 0) {
      songs = album.songs.map(song => ({
        videoId: song.videoId,
        title: song.name || song.title,
        channelTitle: (song.artist && song.artist.name) || (album.artist && album.artist.name) || 'Unknown Artist',
        thumbnail: toHDUrl(song.videoId ? `https://i.ytimg.com/vi/${song.videoId}/mqdefault.jpg` : 
                   (song.thumbnails && song.thumbnails.length > 0 ? song.thumbnails[0].url : '')),
        thumbnailHigh: toHDUrl(song.videoId ? `https://i.ytimg.com/vi/${song.videoId}/hqdefault.jpg` : 
                      (song.thumbnails && song.thumbnails.length > 0 ? song.thumbnails[song.thumbnails.length - 1].url : '')),
        publishedAt: album.year ? `${album.year}-01-01T00:00:00Z` : new Date().toISOString()
      }));
    }
    
    res.json({
      id: album.albumId || id,
      title: album.name || album.title,
      creator: (album.artist && album.artist.name) || (typeof album.artist === 'string' ? album.artist : 'YouTube Music'),
      coverImage: toHDUrl(album.thumbnails && album.thumbnails.length > 0 ? album.thumbnails[album.thumbnails.length - 1].url : ''),
      searchQueries: [],
      preloadedSongs: songs
    });
  } catch (error) {
    console.error('Error fetching album:', error);
    res.status(500).json({ error: 'Failed to fetch album' });
  }
});

// Playlist details endpoint
app.get('/api/playlist', async (req, res) => {
  const id = req.query.id;
  if (!id) return res.status(400).json({ error: 'id required' });
  try {
    const yt = await getYTMusic();
    let playlistId = id;
    if (playlistId.startsWith('VL')) {
      playlistId = playlistId.substring(2);
    }
    
    if (playlistId.startsWith('RD')) {
      const data = await yt.constructRequest('next', { playlistId, isAudioOnly: true });
      const queueRenderer = data.contents?.singleColumnMusicWatchNextResultsRenderer?.tabbedRenderer?.watchNextTabbedResultsRenderer?.tabs[0]?.tabRenderer?.content?.musicQueueRenderer;
      const contents = queueRenderer?.content?.playlistPanelRenderer?.contents || [];
      const subtitle = queueRenderer?.header?.musicQueueHeaderRenderer?.subtitle?.runs?.[0]?.text || 'YouTube Mix';
      
      let songs = contents.map(item => item.playlistPanelVideoRenderer).filter(Boolean).map(item => ({
        videoId: item.videoId,
        title: item.title?.runs?.[0]?.text || 'Unknown',
        channelTitle: item.shortBylineText?.runs?.map(r => r.text).join('') || 'Unknown Artist',
        thumbnail: toHDUrl(item.thumbnail?.thumbnails?.[0]?.url || ''),
        thumbnailHigh: toHDUrl(item.thumbnail?.thumbnails?.at(-1)?.url || ''),
        duration: parseDurationToSeconds(item.lengthText?.runs?.[0]?.text || '0:00'),
        publishedAt: new Date().toISOString()
      }));

      return res.json({
        id: playlistId,
        title: subtitle,
        creator: 'YouTube Music',
        coverImage: toHDUrl(songs.length > 0 ? songs[0].thumbnailHigh : ''),
        searchQueries: [],
        preloadedSongs: songs
      });
    }

    // Get playlist metadata
    const playlist = await yt.getPlaylist(playlistId);
    
    // getPlaylist returns metadata but 0 tracks, use getPlaylistVideos for actual songs
    let songs = [];
    try {
      const videos = await yt.getPlaylistVideos(playlistId);
      songs = (videos || []).map(song => ({
        videoId: song.videoId,
        title: song.name || song.title,
        channelTitle: (song.artist && song.artist.name) || (typeof song.artist === 'string' ? song.artist : 'Unknown Artist'),
        thumbnail: toHDUrl(song.thumbnails && song.thumbnails.length > 0 ? song.thumbnails[0].url : (song.videoId ? `https://i.ytimg.com/vi/${song.videoId}/mqdefault.jpg` : '')),
        thumbnailHigh: toHDUrl(song.thumbnails && song.thumbnails.length > 0 ? song.thumbnails[song.thumbnails.length - 1].url : (song.videoId ? `https://i.ytimg.com/vi/${song.videoId}/hqdefault.jpg` : '')),
        duration: song.duration,
        publishedAt: new Date().toISOString()
      }));
    } catch (e) {
      console.warn('getPlaylistVideos failed, trying getPlaylist tracks:', e.message);
      // Fallback to whatever getPlaylist returned (likely 0 but try anyway)
      songs = (playlist.videos || playlist.songs || playlist.tracks || []).map(song => ({
        videoId: song.videoId,
        title: song.name || song.title,
        channelTitle: (song.artist && song.artist.name) || 'Unknown Artist',
        thumbnail: toHDUrl(song.thumbnails && song.thumbnails.length > 0 ? song.thumbnails[0].url : (song.videoId ? `https://i.ytimg.com/vi/${song.videoId}/mqdefault.jpg` : '')),
        thumbnailHigh: toHDUrl(song.thumbnails && song.thumbnails.length > 0 ? song.thumbnails[song.thumbnails.length - 1].url : (song.videoId ? `https://i.ytimg.com/vi/${song.videoId}/hqdefault.jpg` : '')),
        publishedAt: new Date().toISOString()
      }));
    }
    
    res.json({
      id: playlist.playlistId || id,
      title: playlist.name || playlist.title,
      creator: (playlist.author && playlist.author.name) || (playlist.artist && playlist.artist.name) || (typeof playlist.author === 'string' ? playlist.author : 'YouTube Music'),
      coverImage: toHDUrl(playlist.thumbnails && playlist.thumbnails.length > 0 ? playlist.thumbnails[playlist.thumbnails.length - 1].url : (songs.length > 0 ? songs[0].thumbnailHigh : '')),
      searchQueries: [],
      preloadedSongs: songs
    });
  } catch (error) {
    console.error('Error fetching playlist:', error);
    res.status(500).json({ error: 'Failed to fetch playlist' });
  }
});

// Radio / Related Tracks endpoint (uses official YouTube Music RDAMVM radio mix)
app.get('/api/radio', async (req, res) => {
  const videoId = (req.query.videoId || '').toString().trim();
  if (!videoId) return res.status(400).json({ error: 'videoId required' });

  try {
    const yt = await getYTMusic();
    const data = await yt.constructRequest('next', { playlistId: 'RDAMVM' + videoId, isAudioOnly: true });
    const queueRenderer = data.contents?.singleColumnMusicWatchNextResultsRenderer?.tabbedRenderer?.watchNextTabbedResultsRenderer?.tabs[0]?.tabRenderer?.content?.musicQueueRenderer;
    const contents = queueRenderer?.content?.playlistPanelRenderer?.contents || [];

    let songs = contents
      .map(item => item.playlistPanelVideoRenderer)
      .filter(Boolean)
      .map(item => {
        const thumbs = item.thumbnail?.thumbnails || [];
        const rawDuration = item.lengthText?.runs?.[0]?.text || '';
        return {
          videoId: item.videoId,
          title: item.title?.runs?.[0]?.text || 'Unknown',
          channelTitle: item.shortBylineText?.runs?.map(r => r.text).join('') || 'Unknown Artist',
          thumbnail: toHDUrl(thumbs[0]?.url || (item.videoId ? `https://i.ytimg.com/vi/${item.videoId}/mqdefault.jpg` : '')),
          thumbnailHigh: toHDUrl(thumbs[thumbs.length - 1]?.url || (item.videoId ? `https://i.ytimg.com/vi/${item.videoId}/hqdefault.jpg` : '')),
          duration: parseDurationToSeconds(rawDuration),
          publishedAt: new Date().toISOString()
        };
      })
      .filter(s => s.videoId && s.videoId !== videoId);

    // Fallback if radio had fewer than 5 tracks
    if (songs.length < 5) {
      const q = (req.query.query || '').toString().trim() || videoId;
      const searchRes = await yt.searchSongs(`${q} similar songs`);
      const existing = new Set(songs.map(s => s.videoId));
      (searchRes || []).forEach(s => {
        if (!s.videoId || s.videoId === videoId || existing.has(s.videoId)) return;
        existing.add(s.videoId);
        const thumbs = s.thumbnails || [];
        songs.push({
          videoId: s.videoId,
          title: s.name || s.title,
          channelTitle: (s.artist && s.artist.name) || (typeof s.artist === 'string' ? s.artist : '') || 'Unknown Artist',
          thumbnail: toHDUrl(thumbs[0]?.url || `https://i.ytimg.com/vi/${s.videoId}/mqdefault.jpg`),
          thumbnailHigh: toHDUrl(thumbs[thumbs.length - 1]?.url || `https://i.ytimg.com/vi/${s.videoId}/hqdefault.jpg`),
          duration: parseDurationToSeconds(s.duration),
          publishedAt: new Date().toISOString()
        });
      });
    }

    res.json(songs);
  } catch (err) {
    console.error('Radio fetch error:', err.message);
    res.status(500).json({ error: 'Failed to fetch radio tracks' });
  }
});

// Artist search endpoint (ytmusic-api) — returns artists with profile images
app.get('/api/artist-search', async (req, res) => {
  try {
    const q = (req.query.q || '').toString().trim();
    if (!q) return res.json([]);

    const cacheKey = `asearch_${q.toLowerCase()}`;
    const cached = artistCache.get(cacheKey);
    if (cached && Date.now() - cached.ts < ARTIST_CACHE_TTL) {
      return res.json(cached.data);
    }

    const yt = await getYTMusic();
    const artists = await yt.searchArtists(q);
    const top = (artists || []).slice(0, 12).filter(a => a.artistId);

    const toHDUrl = (url) => {
      if (!url) return '';
      if (url.includes('img.youtube.com')) {
        return url.replace('/default.jpg', '/hqdefault.jpg');
      }
      return url
        .replace(/=w\d+-h\d+/, '=w300-h300')
        .replace(/-w\d+-h\d+/, '-w300-h300')
        .replace(/\/s\d+-/, '/s300-');
    };

    const withThumbs = top.map((a) => {
      const thumbs = a.thumbnails || a.thumbs || [];
      const thumb = thumbs[thumbs.length - 1]?.url || thumbs[0]?.url || '';
      return { name: a.name, artistId: a.artistId, thumb: toHDUrl(thumb) };
    });

    artistCache.set(cacheKey, { ts: Date.now(), data: withThumbs });
    res.json(withThumbs);
  } catch (err) {
    console.error('Artist search error:', err.message);
    res.json([]);
  }
});

// Artist details endpoint (ytmusic-api) — name, image, songs
app.get('/api/artist', async (req, res) => {
  try {
    const id = (req.query.id || '').toString().trim();
    if (!id) return res.status(400).json({ error: 'Missing artist id' });

    const cacheKey = `artist_${id}`;
    const cached = artistCache.get(cacheKey);
    if (cached && Date.now() - cached.ts < ARTIST_CACHE_TTL && cached.data?.songs?.length > 5) {
      return res.json(cached.data);
    }

    const yt = await getYTMusic();
    const artist = await yt.getArtist(id);
    if (!artist) return res.status(404).json({ error: 'Artist not found' });

    const toHDUrl = (url) => {
      if (!url) return '';
      if (url.includes('img.youtube.com')) {
        return url.replace('/default.jpg', '/hqdefault.jpg');
      }
      return url
        .replace(/=w\d+-h\d+/, '=w600-h600')
        .replace(/-w\d+-h\d+/, '-w600-h600')
        .replace(/\/s\d+-/, '/s600-');
    };

    let artistSongs = [];
    try {
      artistSongs = await yt.getArtistSongs(id);
    } catch (e) { artistSongs = []; }

    const seen = new Set();
    const songs = [];
    const pushSong = (song) => {
      if (!song || !song.videoId || seen.has(song.videoId)) return;
      seen.add(song.videoId);
      const thumbs = song.thumbnails || song.thumbs || [];
      songs.push({
        videoId: song.videoId,
        title: song.name || song.title,
        channelTitle: (song.artist && song.artist.name) || (typeof song.artist === 'string' ? song.artist : '') || song.channelTitle || artist.name || 'Unknown Artist',
        thumbnail: toHDUrl(thumbs[0]?.url || ''),
        thumbnailHigh: toHDUrl(thumbs[thumbs.length - 1]?.url || thumbs[0]?.url || ''),
        duration: parseDurationToSeconds(song.duration),
        type: 'song'
      });
    };

    (artist.topSongs || []).forEach(pushSong);
    (artistSongs || []).forEach(pushSong);

    // If artist has fewer than 50 songs, do additional searches to get more
    if (songs.length < 50 && artist.name) {
      const searchQueries = [
        `${artist.name} songs`,
        `${artist.name} hits`,
        `${artist.name} all songs`,
        `${artist.name} top songs`,
        `${artist.name} romantic songs`,
        `${artist.name} sad songs`,
        `${artist.name} playlist`,
        `${artist.name} popular songs`,
        `${artist.name} best songs`,
        `${artist.name} audio`
      ];

      try {
        const searchResults = await Promise.all(
          searchQueries.map(q => yt.searchSongs(q).catch(() => []))
        );

        const artistLower = artist.name.toLowerCase();
        for (const results of searchResults) {
          if (Array.isArray(results)) {
            for (const item of results) {
              const itemName = item.name || item.title || '';
              const artistNames = [];
              if (item.artist && item.artist.name) artistNames.push(item.artist.name);
              else if (typeof item.artist === 'string') artistNames.push(item.artist);
              if (Array.isArray(item.artists)) {
                item.artists.forEach(a => {
                  if (a && a.name) artistNames.push(a.name);
                  else if (typeof a === 'string') artistNames.push(a);
                });
              }
              if (item.channelTitle) artistNames.push(item.channelTitle);
              const combinedArtists = artistNames.join(', ');

              if (
                combinedArtists.toLowerCase().includes(artistLower) ||
                itemName.toLowerCase().includes(artistLower) ||
                (artistLower.length > 3 && artist.name.split(' ').some(word => word.length > 2 && (combinedArtists.toLowerCase().includes(word.toLowerCase()) || itemName.toLowerCase().includes(word.toLowerCase()))))
              ) {
                pushSong({
                  videoId: item.videoId,
                  name: itemName,
                  artist: { name: combinedArtists || artist.name },
                  thumbnails: item.thumbnails || item.thumbs || [],
                  duration: item.duration
                });
              }
            }
          }
        }
      } catch (e) {
        console.error('Additional artist search error:', e.message);
      }
    }

    const thumbs = artist.thumbnails || artist.thumbs || [];
    const payload = {
      name: artist.name,
      artistId: id,
      thumb: toHDUrl(thumbs[thumbs.length - 1]?.url || thumbs[0]?.url || ''),
      songs: songs.slice(0, 150)
    };

    artistCache.set(cacheKey, { ts: Date.now(), data: payload });
    res.json(payload);
  } catch (err) {
    console.error('Artist fetch error:', err.message);
    res.status(500).json({ error: 'Failed to fetch artist' });
  }
});

// Suggestions endpoint
app.get('/api/autocomplete', async (req, res) => {
  const query = req.query.q;
  if (!query) {
    return res.status(400).json({ error: 'Query parameter "q" is required' });
  }

  try {
    const yt = await getYTMusic();
    const suggestions = await yt.getSearchSuggestions(query);
    res.json(suggestions);
  } catch (error) {
    console.error('Error during suggestions fetch:', error);
    res.status(500).json({ error: 'An error occurred during fetching suggestions' });
  }
});

// Health check endpoint
// Room analytics endpoint (admin-only; pwd validated via manageads PHP)
app.get('/api/room-analytics', async (req, res) => {
  const pwd = req.query.pwd || '';
  if (!pwd) {
    return res.status(401).json({ status: 'error', message: 'Unauthorized' });
  }

  // Validate the admin password using the shared admin_settings hash (via PHP API)
  const validateUrl = `https://manageads.ganatube.in/analytic-api.php?action=validatePwd&pwd=${encodeURIComponent(pwd)}`;
  try {
    const vres = await fetch(validateUrl);
    const vdata = await vres.json();
    if (vdata.status !== 'success') {
      return res.status(401).json({ status: 'error', message: 'Unauthorized' });
    }
  } catch (e) {
    console.warn('Room analytics pwd validation failed:', e.message);
    return res.status(503).json({ status: 'error', message: 'Validation service unavailable' });
  }

  res.json({ status: 'success', data: getRoomAnalytics() });
});

app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', ytmusicInitialized: !!ytmusicInstance });
});

// Config endpoint for frontend environment variables
app.get('/api/config', (req, res) => {
  res.json({
    firebase: {
      apiKey: process.env.FIREBASE_API_KEY,
      authDomain: process.env.FIREBASE_AUTH_DOMAIN,
      projectId: process.env.FIREBASE_PROJECT_ID,
      storageBucket: process.env.FIREBASE_STORAGE_BUCKET,
      messagingSenderId: process.env.FIREBASE_MESSAGING_SENDER_ID,
      appId: process.env.FIREBASE_APP_ID,
      measurementId: process.env.FIREBASE_MEASUREMENT_ID
    }
  });
});

// Lyrics endpoint
app.get('/api/lyrics', async (req, res) => {
  const videoId = req.query.videoId;
  if (!videoId) {
    return res.status(400).json({ error: 'Query parameter "videoId" is required' });
  }

  try {
    const yt = await getYTMusic();
    const lyrics = await yt.getLyrics(videoId);
    res.json({ lyrics });
  } catch (error) {
    console.error('Error fetching lyrics:', error);
    res.status(500).json({ error: 'An error occurred during fetching lyrics' });
  }
});

// Synced Lyrics endpoint via LRCLIB
app.get('/api/synced-lyrics', async (req, res) => {
  const query = req.query.q;
  if (!query) {
    return res.status(400).json({ error: 'Query parameter "q" is required' });
  }

  try {
    const response = await fetch(`https://lrclib.net/api/search?q=${encodeURIComponent(query)}`);
    if (!response.ok) {
      throw new Error(`LRCLIB returned ${response.status}`);
    }
    const data = await response.json();
    
    // Find the first result with synced lyrics, or just the first result
    if (data && data.length > 0) {
      const bestMatch = data.find(item => item.syncedLyrics) || data[0];
      return res.json(bestMatch);
    }
    
    res.json(null);
  } catch (error) {
    console.error('Error fetching synced lyrics:', error);
    res.status(500).json({ error: 'An error occurred during fetching synced lyrics' });
  }
});



// Search endpoint: strictly powered by npm ytmusic-api (0 quota, unlimited)
app.get('/api/yt-search', async (req, res) => {
  const query = req.query.q || '';
  if (!query) return res.json({ items: [] });

  try {
    const yt = await getYTMusic();
    const songs = await yt.searchSongs(query);
    const items = (songs || []).map(song => {
      const artistName = (song.artist && typeof song.artist === 'object')
        ? song.artist.name
        : (typeof song.artist === 'string' ? song.artist : 'Unknown Artist');
      const thumbs = song.thumbnails || [];
      const thumbUrl = song.videoId 
        ? `https://i.ytimg.com/vi/${song.videoId}/hqdefault.jpg` 
        : (thumbs[0]?.url || '');
      return {
        id: { videoId: song.videoId },
        snippet: {
          title: song.name || song.title,
          channelTitle: artistName,
          thumbnails: {
            default: { url: thumbUrl },
            medium: { url: thumbUrl },
            high: { url: thumbUrl }
          },
          publishedAt: new Date().toISOString()
        }
      };
    });
    res.json({ items });
  } catch (ytmErr) {
    console.warn('[yt-search] YTMusic search error:', ytmErr.message);
    res.json({ items: [] });
  }
});

// Video details endpoint: strictly powered by npm ytmusic-api (0 quota)
app.get('/api/yt-videos', async (req, res) => {
  const ids = (req.query.id || '').split(',').filter(Boolean);
  if (ids.length === 0) return res.json({ items: [] });

  try {
    const yt = await getYTMusic();
    const results = await Promise.all(ids.map(async (id) => {
      try {
        const song = await yt.getSong(id);
        if (!song) return null;
        return {
          id: song.videoId,
          snippet: {
            title: song.name,
            channelTitle: song.artist?.name || 'Unknown Artist',
            publishedAt: new Date().toISOString(),
            thumbnails: {
              medium: { url: `https://img.youtube.com/vi/${song.videoId}/mqdefault.jpg` },
              maxres: { url: `https://img.youtube.com/vi/${song.videoId}/maxresdefault.jpg` },
              standard: { url: `https://img.youtube.com/vi/${song.videoId}/hqdefault.jpg` },
              high: { url: `https://img.youtube.com/vi/${song.videoId}/hqdefault.jpg` }
            }
          },
          contentDetails: {
            duration: `PT${song.duration}S`
          }
        };
      } catch (e) {
        return null;
      }
    }));

    const validItems = results.filter(Boolean);
    res.json({ items: validItems });
  } catch (ytError) {
    console.warn('[yt-videos] YTMusic scraper error:', ytError.message);
    res.json({ items: [] });
  }
});

// ─── JioSaavn Playback Streams (unofficial) ─────────────────────────────────
// ytmusic-api handles ALL discovery (search/albums/artists/radio). These
// endpoints only resolve a direct stream URL for a chosen song so the client
// can play via HTML5 <audio> (background playback + MediaSession).
const { searchSaavnSongs, matchSaavnSong, getTrendingSaavnSongs } = require('./saavnEngine.js');
const saavnCache = new Map();
const SAAVN_CACHE_TTL = 30 * 60 * 1000;

function getSaavnCached(key) {
  const item = saavnCache.get(key);
  if (!item) return null;
  const ttl = item.ttl || SAAVN_CACHE_TTL;
  if (Date.now() - item.time > ttl) {
    saavnCache.delete(key);
    return null;
  }
  return item.data;
}

function setSaavnCached(key, data, ttl = SAAVN_CACHE_TTL) {
  // Keep the cache bounded
  if (saavnCache.size > 500) {
    const oldest = saavnCache.keys().next().value;
    saavnCache.delete(oldest);
  }
  saavnCache.set(key, { time: Date.now(), data, ttl });
}

// JioSaavn Trending & Recommendations endpoint
app.get('/api/saavn/trending', async (req, res) => {
  const lang = String(req.query.language || req.query.lang || 'hindi').toLowerCase().trim();
  const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 20, 1), 60);
  const type = String(req.query.type || 'all').toLowerCase().trim();

  const cacheKey = `trending_${lang}_${limit}_${type}`;
  const cached = getSaavnCached(cacheKey);
  if (cached) return res.json(cached);

  try {
    const songs = await getTrendingSaavnSongs(lang, limit, type);
    const result = { songs, source: 'jiosaavn' };
    setSaavnCached(cacheKey, result, 15 * 60 * 1000); // 15-minute TTL
    res.json(result);
  } catch (err) {
    console.warn('Saavn trending error:', err.message);
    res.status(500).json({ error: 'Failed to fetch trending songs', songs: [], source: 'jiosaavn' });
  }
});

// Search JioSaavn directly (debug / manual fallback)
app.get('/api/saavn/search', async (req, res) => {
  const q = String(req.query.q || '').trim().slice(0, 120);
  if (!q) return res.status(400).json({ error: 'q is required', songs: [] });

  const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 10, 1), 30);
  const bitrateRaw = parseInt(req.query.bitrate, 10) || 320;
  const bitrate = [320, 160, 96].includes(bitrateRaw) ? bitrateRaw : 320;

  const cacheKey = `search_${q.toLowerCase()}_${limit}_${bitrate}`;
  const cached = getSaavnCached(cacheKey);
  if (cached) return res.json(cached);

  try {
    const songs = await searchSaavnSongs(q, limit);
    const result = { songs, source: 'jiosaavn' };
    setSaavnCached(cacheKey, result);
    res.json(result);
  } catch (err) {
    console.warn('Saavn search error:', err.message);
    res.status(500).json({ error: 'Saavn search failed', songs: [] });
  }
});

// Resolve a playable stream for a YouTube Music song (title/artist/duration match or direct songId)
app.get('/api/saavn/match', async (req, res) => {
  const songId = String(req.query.songId || req.query.id || '').trim();
  const title = String(req.query.title || '').trim().slice(0, 120);
  const artist = String(req.query.artist || '').trim().slice(0, 120);
  const album = String(req.query.album || '').trim().slice(0, 120);
  const duration = parseInt(req.query.duration, 10) || 0;
  const bitrateRaw = parseInt(req.query.bitrate, 10) || 320;
  const bitrate = [320, 160, 96].includes(bitrateRaw) ? bitrateRaw : 320;

  if (!title && !songId) return res.status(400).json({ error: 'title or songId is required' });

  const key = songId ? `id_${songId}_${bitrate}` : `${title.toLowerCase().replace(/[^a-z0-9]/g, '')}_${artist.toLowerCase().replace(/[^a-z0-9]/g, '')}_${duration}_${bitrate}`;
  const cached = getSaavnCached(`match_${key}`);
  if (cached) return res.json(cached);

  try {
    const match = await matchSaavnSong({ songId, title, artist, album, duration, bitrate });
    const result = match ? { match } : { match: null, reason: 'no_confident_match' };
    setSaavnCached(`match_${key}`, result);
    res.json(result);
  } catch (err) {
    console.warn('Saavn match error:', err.message);
    res.status(500).json({ error: 'Saavn match failed', match: null });
  }
});

// Redirect share.php requests to the PHP backend so the script executes correctly
app.get('/share.php', (req, res) => {
  res.redirect(301, 'https://manageads.ganatube.in' + req.originalUrl);
});

// Serve Angular static frontend files from 'browser' folder
app.use(express.static(path.join(__dirname, 'dist', 'ganatube', 'browser')));

// Route all other requests to Angular's index.html (SPA routing fallback)
app.use((req, res) => {
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({ error: 'API endpoint not found' });
  }

  // CRITICAL: Never return index.html for missing static assets (images, fonts, scripts, stylesheets)
  // Returning HTML for missing assets corrupts browser caches and creates infinite image error loops
  if (
    /\.(webp|png|jpe?g|gif|svg|ico|css|js|map|woff2?|ttf|eot|webmanifest|mp3|mp4|webm)$/i.test(req.path) ||
    req.path.startsWith('/assets/') ||
    req.path.startsWith('/images/')
  ) {
    return res.status(404).type('text/plain').send('File not found');
  }

  res.sendFile(path.join(__dirname, 'dist', 'ganatube', 'browser', 'index.html'));
});

// Start server
server.listen(PORT, '0.0.0.0', async () => {
  console.log(`GanaTube Backend Server listening at http://localhost:${PORT}`);
  try {
    await getYTMusic();
  } catch (err) {
    console.error('Failed to pre-initialize YTMusic:', err);
  }

  // ── Auto-start GanaTube Discord Bot ──
  try {
    if (process.env.DISCORD_BOT_TOKEN) {
      const { startBot } = require('./bot/index.js');
      startBot();
    }
  } catch (botErr) {
    console.warn('[GanaTube Server] Discord Bot start skipped:', botErr.message);
  }
});

